### Whats up with the Dockerfile?

The `Dockerfile` in this folder is used as the build environment when regenerating the files (see CONTRIBUTING.md).
The canonical repository for this Dockerfile is `docker.pkg.github.com/grpc-ecosystem/grpc-gateway/build-env`.
