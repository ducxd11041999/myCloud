# ExamplepbGenerateUnboundMethodsSimpleMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Id represents the message identifier. | [optional] [default to null]
**Num** | **string** |  | [optional] [default to null]
**Duration** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


